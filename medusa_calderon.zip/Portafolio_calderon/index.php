<?php get_header(); ?>
	

	<div id=cos class="container_12">
		<div id="barra">
			<div class="cita">
			<p>Sin arte la vida sería un error.</p>
			<p>» Friedrich Nietzsche  (1844-1900)</p>
			</div>
			<div id="link1"></div>
		</div>
		<div id="sobremi">
		</div>
		<div id="barra">
			<div id="link2"></div>
		</div>

		<div id="proyectos">
			<div>
			<p id="ptexto" class="push_5">PROYECTOS</p>
			</div>
			<div class="foto1 grid_3"></div>
			<div class="foto2 grid_3"></div>
			<div class="foto3 grid_3"></div>
			<div class="foto4 grid_3"></div>
			<div class="foto5 grid_3"></div>
			<div class="foto6 grid_3"></div>
			<div class="foto7 grid_3"></div>
			<div class="foto8 grid_3"></div>
			
		</div>
		<div id="barraproyectos">
			
		</div>
		<div>
			<p id="ctexto" class="push_5">CONTACTO</p>
		
			<form>
			<input class="nombre grid_4 push_4" type="text" name="contacto" placeholder="Nombre" >
			<br>
			<input class="email grid_4 push_4" type="text" name="contacto" placeholder="Email" >
			<br>
			<input class="asunto grid_4 push_4" type="text" name="contacto" placeholder="Asunto" >
			<br>
			<input class="mensaje grid_4 push_4" type="text" name="contacto" placeholder="Mensaje" >
			<br>
			</form>

		<p class="enviar push_7"><a href="http://www.gmail.com" target="_blank">Enviar</a></p>


		</div>

	</div>

<?php get_footer(); ?>
