	<div id=peu class="container_12">
		<div id="barrapeu">
			<p class="copy">© 2017</br>
			Medusa Graphic Design</p>
			
		</div>
		
	</div>
	
	
</body>
</html>