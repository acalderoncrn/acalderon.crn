<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Cars and films</title>
	<link rel="stylesheet" href="css/renset.css">
	<link rel="stylesheet" href="css/gwd.css">
	<link rel="stylesheet" href="css/stylez.css">

</head>
<body>

	<div id="cap" class="container_12">
		<h1 class="grid_3 push_4" >cars<b>and</b>films</h1>
		
	</div>