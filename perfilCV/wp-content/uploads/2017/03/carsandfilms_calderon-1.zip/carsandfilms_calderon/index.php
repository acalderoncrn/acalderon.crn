<?php get_header(); ?>

	<div id="cos" class="container_12">
		<div class="grid_4"><img class="pulp" src="img/small_pulp.jpg"><p>Pulp Fiction</p></div>
		<div class="grid_4"><img class="taxi" src="img/small_taxi.jpg"><p>Taxi Driver</p></div>
		<div class="grid_4"><img class="bond" src="img/small_bond.jpg"><p>Goldfinger</p></div>
		<div class="grid_4"><img class="ghost" src="img/small_ghost.jpg"><p>Ghost Busters</p></div>
		<div class="grid_4"><img class="bean" src="img/small_bean.jpg"><p>Mr. Bean</p></div>
		<div class="grid_4"><img class="back" src="img/small_back.jpg"><p>Back to the Future</p></div>
		<div class="grid_4"><img class="rider" src="img/small_rider.jpg"><p>Knight Rider</p></div>
		<div class="grid_4"><img class="team " src="img/small_team.jpg"><p>The A-Team</p></div>
		<div class="grid_4"><img class="break" src="img/small_break.jpg"><p>Breaking Bad</p></div>
		
		
	</div>

<?php get_footer(); ?>